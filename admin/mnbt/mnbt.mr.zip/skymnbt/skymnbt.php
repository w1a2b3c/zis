<?php
//消失的天空·QQ:3557289004
function skymnbt_MetaData() {
    return ["DisplayName" => "梦奈宝塔对接模块", "APIVersion" => "1.0.2", "HelpDoc" => "https://www.52-tk.cn/"];
}

function request_post($url = '', $post_data = array()) {
    if (empty($url) || empty($post_data)) {
        return false;
    }
    $o = "";
    foreach ($post_data as $k => $v) {
        $o.= "$k=" . urlencode($v). "&" ;
    }
    $post_data = substr($o,0,-1);
    $postUrl = $url;
    $curlPost = $post_data;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$postUrl);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}
function skymnbt_ConfigOptions() {
    return [
        ["type" => "text", "name" => "Web空间大小", "description" => "MB", "key" => "a1"],
        ["type" => "text", "name" => "Sql空间大小", "description" => "MB", "key" => "a2"],
        ["type" => "text", "name" => "流量限制", "description" => "GB/月", "key" => "a3"],
        ["type" => "text", "name" => "产品类型", "description" => "1为CDN，2为主机", "key" => "a4"],
        ["type" => "text", "name" => "绑定域名数", "description" => "个，0为无限", "key" => "a5"],
        ["type" => "text", "name" => "备注", "description" => "用于前台显示", "key" => "note"]
    ];
}



function skymnbt_TestLink($params){
    if (empty($params["password"])) {
        $sys_pwd = randStr(8);
    } else {
        $sys_pwd = $params["password"];
    }
    if ($params['port'] == 443 || $params['secure'] == true) {
        $http = 'https://';
    } else {
        $http = 'http://';
    }
    $url = $http.$params["server_host"].'/api/api.php?gn=cfif';
        $postdata = [
        "mn_bh" => $params["server_ip"],
        "mn_key" => $params["server_password"],
        "mn_keye" => $params["server_username"],
        "mn_vs" => 16,
        "username" => 'mnbt_link'
    ];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata['code'] != '200') {
        return ['status' => '200', 'data'=>['server_status'=>0,'msg' =>$resultdata['msg']]];
    } else {
        return ['status' => '200', 'data'=>['server_status'=>1,'msg' =>$resultdata['msg']]];
    }
}


function skymnbt_CreateAccount($params) {
    if ($params["configoptions"]["a1"] == null || $params["configoptions"]["a2"] == null || $params["configoptions"]["a3"] == null || $params["configoptions"]["a4"] == null || $params["configoptions"]["a5"] == null) {
        return "参数设置错误，请检查";
    }
    if (empty($params["password"])) {
        $sys_pwd = randStr(8);
    } else {
        $sys_pwd = $params["password"];
    }
    if ($params['port'] == 443 || $params['secure'] == true) {
        $http = 'https://';
    } else {
        $http = 'http://';
    }
    $url = $http.$params["server_host"].'/api/api.php?gn=kt';
    $postdata = [
        "mn_bh" => $params["server_ip"],
        "mn_key" => $params["server_password"],
        "mn_keye" => $params["server_username"],
        "mn_vs" => 16,
        "username" => $params["domain"],
        "password" => $sys_pwd,
        "webdx" => $params["configoptions"]["a1"],
        "sqldx" => $params["configoptions"]["a2"],
        "sizemax" => $params["configoptions"]["a3"],
        "type" => $params["configoptions"]["a4"],
        "ymbds" => $params["configoptions"]["a5"],
        "dqtime" => 0
    ];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata['code'] != '200') {
        return ['code' => 'error', 'msg' =>$resultdata['msg']];
    } else {
        $update["password"] = cmf_encrypt($sys_pwd);
        $update["dedicatedip"] = $params["server_ip"];
        $update["username"] = $params["domain"];
        \think\Db::name("host")->where("id", $params["hostid"])->update($update);
        return "success";
    }
}
function skymnbt_SuspendAccount($params) {
    if ($params['port'] == 443 || $params['secure'] == true) {
        $http = 'https://';
    } else {
        $http = 'http://';
    }
    $url = $http.$params["server_host"].'/api/api.php?gn=zt';
    $postdata = [
        "mn_bh" => $params["server_ip"],
        "mn_key" => $params["server_password"],
        "mn_keye" => $params["server_username"],
        "mn_vs" => 16,
        "username" => $params["username"]
    ];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata['code'] != '200') {
        return ['code' => 'error', 'msg' => $resultdata['msg']];
    } else {
        return "success";
    }
}
function skymnbt_UnSuspendAccount($params) {
    if ($params['port'] == 443 || $params['secure'] == true) {
        $http = 'https://';
    } else {
        $http = 'http://';
    }
    $url = $http.$params["server_host"].'/api/api.php?gn=jc';
    $postdata = [
        "mn_bh" => $params["server_ip"],
        "mn_key" => $params["server_password"],
        "mn_keye" => $params["server_username"],
        "mn_vs" => 16,
        "username" => $params["username"]
    ];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata['code'] != '200') {
        return ['code' => 'error', 'msg' => $resultdata['msg']];
    } else {
        return "success";
    }
}
function skymnbt_TerminateAccount($params) {
    if ($params['port'] == 443 || $params['secure'] == true) {
        $http = 'https://';
    } else {
        $http = 'http://';
    }
    $url = $http.$params["server_host"].'/api/api.php?gn=tz';
    $postdata = [
        "mn_bh" => $params["server_ip"],
        "mn_key" => $params["server_password"],
        "mn_keye" => $params["server_username"],
        "mn_vs" => 16,
        "username" => $params["username"]
    ];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata['code'] != '200') {
        return ['code' => 'error', 'msg' => $resultdata['msg']];
    } else {
        return "success";
    }
}
function skymnbt_CrackPassword($params, $new_pass) {
    if ($params['port'] == 443 || $params['secure'] == true) {
        $http = 'https://';
    } else {
        $http = 'http://';
    }
    $url = $http.$params["server_host"].'/api/api.php?gn=czmm';
    $postdata = [
        "mn_bh" => $params["server_ip"],
        "mn_key" => $params["server_password"],
        "mn_keye" => $params["server_username"],
        "mn_vs" => 16,
        "username" => $params["username"],
        "password" => $new_pass
    ];
    $resultdata = request_post($url, $postdata);
    $resultdata = json_decode($resultdata, true);
    if ($resultdata['code'] != '200') {
        return ['code' => 'error', 'msg' => $resultdata['msg']];
    } else {
        return "success";
    }
}
function skymnbt_ClientArea($params) {
    return [
        "msgrmation" => [
            "name" => "产品详情"
        ]
    ];
}
function skymnbt_ClientAreaOutput($params, $key) {
    if ($key == "msgrmation") {
        if ($params['port'] == 443 || $params['secure'] == true) {
            $http = 'https://';
        } else {
            $http = 'http://';
        }
        $url = $http.$params["server_host"].'/user/idcdl.php?gn=logine';
        return [
            "template" => "templates/information.html",
            "vars" => [
                "url" => $url,
                "product_name" => $params["name"],
                "username" => $params["username"],
                "password" => $params["password"],
                "note" => $params["configoptions"]["note"]
            ]
        ];
    }
}