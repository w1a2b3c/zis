<?php

//SWAPIDC对接MN宝塔主机系统
//作者：梦奈
//邮箱：2392622648@qq.com
//QQ：2392622648

function send_post($url, $post_data) {
$post_data['mn_vs']='15';//MNBT插件所支持的版本
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
      'method' => 'POST',
      'header' => 'Content-type:application/x-www-form-urlencoded',
      'content' => $postdata,
      'timeout' => 15 * 60 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  return json_decode($result,true);
}


function MNBT_ConfigOptions()
{
    $configarray = array(
    "域名绑定数" => array("Type" => "text", "Description" => "域名最大绑定数不限请填0(单位个,填写数字)"),
    "网页空间" => array("Type" => "text", "Description" => "网站储存的总文件的最大大小(单位MB,填写数字)"),
    "数据库空间" => array("Type" => "text", "Description" => "数据库储存的总数据的最大大小(单位MB,填写数字)"),
    "最大每月流量" => array("Type" => "text", "Description" => "每个月最多可用多少流量(单位G,填写数字)")
    );
    return $configarray;
}

function MNBT_CreateAccount($params){
	$cp = get_query_vals('服务', '*', array('id' => $params['serviceid']));
	$serza='m'.mt_rand(1000,9999).mt_rand(10,99).'n';
    $MNBT_POSTDATA = array(
			'mn_bh' => $params['serverusername'],
			'mn_key' => $params['serverpassword'],
            'mn_keye' => $params['serveraccesshash'],
            'username' => $serza,
            'password' => $params['password'],
            'ymbds' => $params['configoption1'],
            'webdx' => $params['configoption2'],
            'sqldx' => $params['configoption3'],
            'sizemax' => $params['configoption4'],
            'dqtime' => $cp['到期时间']
	);
	if($params['serversecure']==1){
	$xy='https';
	}else{
	$xy='http';
	}
	
	$content = send_post($xy.'://'.$params['serverhostname'].'/api/api.php?gn=kt',$MNBT_POSTDATA);
	if($content['code'] == 200){
			update_query("服务", array("密码" => encrypt($params['password']), "用户名"=>$serza),array("id" => $params['serviceid']));
			return '成功';
	}else{
		return $content['msg'];
	}
}

function MNBT_ServerRenewalAccount($params){

	$cp = get_query_vals('服务', '*', array('id' => $params['serviceid']));
	$ezq=$cp['周期'];
	$gmsl=$cp['购买数量'];
	$dq=$cp['到期时间'];
	if($ezq=='日付'){$sjop=1*$gmsl;}elseif($ezq=='周付'){$sjop=7*$gmsl;}elseif($ezq=='月付'){$sjop=30*$gmsl;}elseif($ezq=='年付'){$sjop=365*$gmsl;}else{exit('时间错误');}
	$daq=strtotime($dq)+$sjop*86400;
	$daoqidate=date('Y-m-d',$daq);
	
    $MNBT_POSTDATA = array(
			'mn_bh' => $params['serverusername'],
			'mn_key' => $params['serverpassword'],
            'mn_keye' => $params['serveraccesshash'],
            'username' => $params['username'],
            'setdate' => $daoqidate

	);
	
	if($params['serversecure']==1){
	$xy='https';
	}else{
	$xy='http';
	}
   $content = send_post($xy.'://'.$params['serverhostname'].'/api/api.php?gn=xf',$MNBT_POSTDATA);
	if($content['code'] == 200){
			return '成功';
	}else{
		return $content;
	}
	
//print_r($params);
}

function MNBT_SuspendAccount($params){
    $MNBT_POSTDATA = array(
			'mn_bh' => $params['serverusername'],
			'mn_key' => $params['serverpassword'],
            'mn_keye' => $params['serveraccesshash'],
            'username' => $params['username']
	);
	if($params['serversecure']==1){
	$xy='https';
	}else{
	$xy='http';
	}
    $content = send_post($xy.'://'.$params['serverhostname'].'/api/api.php?gn=zt',$MNBT_POSTDATA);
	if($content['code'] == 200){
			update_query("服务", array("状态" => "暂停"),array("id" => $params['serviceid']));
			return '成功';
	}else{
		return $content['msg'];
	}
}

function MNBT_TerminateAccount($params){
    $MNBT_POSTDATA = array(
			'mn_bh' => $params['serverusername'],
			'mn_key' => $params['serverpassword'],
            'mn_keye' => $params['serveraccesshash'],
            'username' => $params['username']
	);
	if($params['serversecure']==1){
	$xy='https';
	}else{
	$xy='http';
	}
    $content = send_post($xy.'://'.$params['serverhostname'].'/api/api.php?gn=tz',$MNBT_POSTDATA);
	if($content['code'] == 200){
			update_query("服务", array("状态" => "停止"),array("id" => $params['serviceid']));
			return '成功';
	}else{
		return $content['msg'];
	}
}

function MNBT_ClientArea($params ){	
$str1 = '<ui><form action="http://'.$params["serverhostname"].'/user/idcdl.php?gn=logine" method="post" target="_blank"><input type="hidden" name="username" value="'.$params['username'].'" /><input type="hidden" name="password" value="'.$params['password'].'" /><input type="submit" class="btn btn-success btn-block" value="直接登录(自定义密码无效)"/></form>';
$str2 = '<a href="http://'.$params["serverhostname"].'/user/idcdl.php?gn=xz" target="_blank" class="btn btn-primary btn-block">打开登录地址</a>';
return array($str1, $str2);
}


function MNBT_UnsuspendAccount($params){
	$cp = get_query_vals('服务', '*', array('id' => $params['serviceid']));
    $MNBT_POSTDATA = array(
			'mn_bh' => $params['serverusername'],
			'mn_key' => $params['serverpassword'],
            'mn_keye' => $params['serveraccesshash'],
            'username' => $params['username']
	);
	if($params['serversecure']==1){
	$xy='https';
	}else{
	$xy='http';
	}
    $content = send_post($xy.'://'.$params['serverhostname'].'/api/api.php?gn=jc',$MNBT_POSTDATA);
	if($content['code'] == 200){
			update_query("服务", array("状态" => "激活"),array("id" => $params['serviceid']));
			return '成功';
	}else{
		return $content['msg'];
	}
}

function MNBT_ChangePassword($params){
    $MNBT_POSTDATA = array(
			'mn_bh' => $params['serverusername'],
			'mn_key' => $params['serverpassword'],
            'mn_keye' => $params['serveraccesshash'],
            'username' => $params['username'],
            'password' => $params['password']
	);
	if($params['serversecure']==1){
	$xy='https';
	}else{
	$xy='http';
	}
    $content = send_post($xy.'://'.$params['serverhostname'].'/api/api.php?gn=czmm',$MNBT_POSTDATA);
	if($content['code'] == 200){
			//update_query("服务", array("密码" => $params['password']),array("id" => $params['serviceid']));
			return '成功';
	}else{
		return $content['msg'];
	}
}

?>